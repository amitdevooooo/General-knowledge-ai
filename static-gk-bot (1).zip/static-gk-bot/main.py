
import telebot
import requests
import datetime
import time
import threading

# === CONFIGURATION ===
BOT_TOKEN = "7992369115:AAHClwij4Y1fjdTlHByn1_dwsQ5yhdsgh-4"
CHAT_ID = "-1002849021886"
GEMINI_API_KEY = "AIzaSyAaq1cziEhGEYbhWl64zuykOROSiWFyRXQ"

bot = telebot.TeleBot(BOT_TOKEN)

# === GEMINI AI Q&A FUNCTION ===
def ask_gemini(question):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={GEMINI_API_KEY}"
    headers = {"Content-Type": "application/json"}
    data = {
        "contents": [
            {
                "parts": [{"text": question}]
            }
        ]
    }
    response = requests.post(url, headers=headers, json=data)
    try:
        return response.json()['candidates'][0]['content']['parts'][0]['text']
    except:
        return "❌ माफ़ कीजिए, मैं अभी जवाब नहीं दे पा रहा हूँ।"

# === AI AUTO Q&A SYSTEM ===
@bot.message_handler(func=lambda message: True)
def handle_message(message):
    if str(message.chat.id) == CHAT_ID:
        question = message.text
        answer = ask_gemini(question)
        bot.reply_to(message, answer)

# === DAILY CONTENT POSTING (Current Affairs + Quiz) ===
def send_daily_content():
    sent_today = False
    while True:
        now = datetime.datetime.now()
        if now.hour == 10 and not sent_today:
            daily_message = (
                "📅 *आज का करंट अफेयर्स और क्विज़:*

"
                "1. भारत का पहला AI जिला कौन बना?
(a) हैदराबाद
(b) जोधपुर
(c) जामनगर
(d) हरिद्वार

"
                "2. हाल ही में किसने ओलंपिक में कोटा जीता?
(a) पीवी सिंधु
(b) नीरज चोपड़ा
(c) मैरी कॉम
(d) बजरंग पूनिया

"
                "*उत्तर:*
1. (d), 2. (b)"
            )
            bot.send_message(CHAT_ID, daily_message, parse_mode='Markdown')
            sent_today = True
        if now.hour == 11:
            sent_today = False
        time.sleep(60)

# === THREAD FOR DAILY POSTS ===
threading.Thread(target=send_daily_content, daemon=True).start()

# === RUN BOT ===
print("🤖 Static GK Bot is now running...")
bot.infinity_polling()
